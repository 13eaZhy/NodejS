console.log("Server Starting... ");

/////////////// FUNCTIONS ///////////////
let loadCurrencies = () => {
    //citeste datele din baza de date
    let data = require('./data/currencies.json');
    return data;
}

////////////////ROUTES////////////////

let apiCurrencyList = (req, res) => {
    if (req.url == '/currencies'){
        res.end( JSON.stringify ( loadCurrencies() ) );
    } else if (req.url.startsWith ('/currency/') ){
        //extragem parapetru din URL
        // /some /path / %%% - url parameters
        let code = req.url.split('/').pop();
        let data = loadCurrencies();
            for (let i = 0; i<data.length;i++){
                if (data[i].code == code){
                    res.write(JSON.stringify( data[i] ));
                    break;
                }
            }
        res.end ();
    } else {
        res.writeHead(404, {
            //alte headers
        })
        res.end( http.STATUS_CODES[404] );
    }
}

/////////////////////////////////////////

///////////////HTTP Server///////////////
let http = require ('http');
    let servre = http.createServer ( apiCurrencyList );
        servre.listen('7777');
/////////////////////////////////////////

//console.log(loadCurrencies() );